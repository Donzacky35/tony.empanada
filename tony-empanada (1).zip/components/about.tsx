export default function About() {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Nuestra Historia</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <p className="text-lg mb-4">
              Tony Empanada nació de la pasión por la comida tradicional y el deseo de compartir el auténtico sabor de
              las empanadas fritas con todos.
            </p>
            <p className="text-lg mb-4">
              Desde 2015, hemos estado sirviendo empanadas recién hechas con las mejores recetas familiares transmitidas
              por generaciones.
            </p>
            <p className="text-lg">
              Nuestro compromiso es ofrecer productos de la más alta calidad, utilizando ingredientes frescos y locales
              para crear una experiencia gastronómica inolvidable.
            </p>
          </div>
          <div className="rounded-lg overflow-hidden shadow-xl">
            <img src="/placeholder.svg?height=600&width=800" alt="Preparación de empanadas" className="w-full h-auto" />
          </div>
        </div>
      </div>
    </section>
  )
}

