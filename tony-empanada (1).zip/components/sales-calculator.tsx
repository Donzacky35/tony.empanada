"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Calculator } from "lucide-react"

// Importamos los datos de las empanadas del menú
interface Empanada {
  id: number
  name: string
  description: string
  price: string
  image: string
}

// Usamos los mismos datos que en el menú
const empanadas: Empanada[] = [
  {
    id: 1,
    name: "Empanada de Res",
    description: "Rellena de carne molida",
    price: "40",
    image: "/placeholder.svg?height=300&width=300",
  },
  {
    id: 2,
    name: "Empanada de Pollo",
    description: "Rellena de pollo",
    price: "40",
    image: "/placeholder.svg?height=300&width=300",
  },
  {
    id: 3,
    name: "Empanada de Jamón y Queso",
    description: "Rellena de jamón y queso",
    price: "40",
    image: "/placeholder.svg?height=300&width=300",
  },
  {
    id: 4,
    name: "Empanada de Camarone",
    description: "Rellena de camarone",
    price: "60",
    image: "/placeholder.svg?height=300&width=300",
  },
]

export default function SalesCalculator() {
  // Estado para almacenar las cantidades de cada empanada
  const [quantities, setQuantities] = useState<{ [key: number]: number }>(
    empanadas.reduce(
      (acc, empanada) => {
        acc[empanada.id] = 0
        return acc
      },
      {} as { [key: number]: number },
    ),
  )

  // Estado para almacenar el total de la venta
  const [total, setTotal] = useState(0)
  const [showResults, setShowResults] = useState(false)

  // Función para manejar cambios en las cantidades
  const handleQuantityChange = (id: number, value: string) => {
    const newQuantities = { ...quantities }
    newQuantities[id] = Number.parseInt(value) || 0
    setQuantities(newQuantities)
  }

  // Función para calcular el total
  const calculateTotal = () => {
    let newTotal = 0
    empanadas.forEach((empanada) => {
      newTotal += quantities[empanada.id] * Number.parseInt(empanada.price)
    })
    setTotal(newTotal)
    setShowResults(true)
  }

  // Función para resetear la calculadora
  const resetCalculator = () => {
    setQuantities(
      empanadas.reduce(
        (acc, empanada) => {
          acc[empanada.id] = 0
          return acc
        },
        {} as { [key: number]: number },
      ),
    )
    setTotal(0)
    setShowResults(false)
  }

  return (
    <section id="calculator" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Calculadora de Ventas</h2>

        <Card className="max-w-3xl mx-auto">
          <CardHeader className="bg-amber-50">
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-6 w-6" />
              <span>Calcular Ventas</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {empanadas.map((empanada) => (
                  <div key={empanada.id} className="space-y-2">
                    <div className="flex justify-between">
                      <Label htmlFor={`quantity-${empanada.id}`}>{empanada.name}</Label>
                      <span className="text-amber-600 font-medium">${empanada.price}</span>
                    </div>
                    <Input
                      id={`quantity-${empanada.id}`}
                      type="number"
                      min="0"
                      value={quantities[empanada.id]}
                      onChange={(e) => handleQuantityChange(empanada.id, e.target.value)}
                      placeholder="0"
                    />
                  </div>
                ))}
              </div>

              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button onClick={calculateTotal} className="bg-amber-600 hover:bg-amber-700 flex-1">
                  Calcular Total
                </Button>
                <Button onClick={resetCalculator} variant="outline" className="flex-1">
                  Reiniciar
                </Button>
              </div>

              {showResults && (
                <div className="mt-6 pt-6 border-t">
                  <h3 className="text-xl font-bold mb-4">Resumen de Venta</h3>
                  <div className="space-y-2">
                    {empanadas.map(
                      (empanada) =>
                        quantities[empanada.id] > 0 && (
                          <div key={`summary-${empanada.id}`} className="flex justify-between">
                            <span>
                              {empanada.name} x {quantities[empanada.id]}
                            </span>
                            <span className="font-medium">
                              ${Number.parseInt(empanada.price) * quantities[empanada.id]}
                            </span>
                          </div>
                        ),
                    )}
                    <div className="flex justify-between pt-4 border-t mt-4">
                      <span className="text-lg font-bold">Total</span>
                      <span className="text-lg font-bold text-amber-600">${total}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}

