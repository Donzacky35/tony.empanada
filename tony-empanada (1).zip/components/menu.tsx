import { Card, CardContent } from "@/components/ui/card"

interface Empanada {
  id: number
  name: string
  description: string
  price: string
  image: string
}

const empanadas: Empanada[] = [
  {
    id: 1,
    name: "Empanada de Res",
    description: "Rellena de carne molida",
    price: "40",
    image: "/placeholder.svg?height=300&width=300",
  },
  {
    id: 2,
    name: "Empanada de Pollo",
    description: "Rellena de pollo",
    price: "40",
    image: "/placeholder.svg?height=300&width=300",
  },
  {
    id: 3,
    name: "Empanada de Jamón y Queso",
    description: "Rellena de jamón y queso",
    price: "40",
    image: "/placeholder.svg?height=300&width=300",
  },
  {
    id: 4,
    name: "Empanada de Camarone",
    description: "Rellena de camarone",
    price: "60",
    image: "/placeholder.svg?height=300&width=300",
  },

]

export default function Menu() {
  return (
    <section id="menu" className="py-16 bg-amber-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Nuestro Menú</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {empanadas.map((empanada) => (
            <Card key={empanada.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="h-48 overflow-hidden">
                <img
                  src={empanada.image || "/placeholder.svg"}
                  alt={empanada.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl font-bold">{empanada.name}</h3>
                  <span className="text-lg font-semibold text-amber-600">{empanada.price}</span>
                </div>
                <p className="text-gray-600">{empanada.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="mt-12 text-center">
          <p className="text-lg font-semibold mb-4">También ofrecemos:</p>
          <ul className="inline-block text-left">
            <li className="mb-2">✓ Bebidas refrescantes</li>
            <li className="mb-2">✓ Postres caseros</li>
            <li className="mb-2">✓ Opciones vegetarianas</li>
            <li>✓ Pedidos para eventos</li>
          </ul>
        </div>
      </div>
    </section>
  )
}

