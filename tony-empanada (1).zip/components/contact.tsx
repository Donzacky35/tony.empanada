import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { MapPin, Phone, Mail, Clock } from "lucide-react"

export default function Contact() {
  return (
    <section id="contact" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Contáctanos</h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <h3 className="text-2xl font-bold mb-6">Información de Contacto</h3>

            <div className="space-y-6">
              <div className="flex items-start">
                <MapPin className="w-6 h-6 text-amber-600 mr-4 mt-1" />
                <div>
                  <h4 className="font-semibold text-lg">Dirección</h4>
                  <p>#81 Calle Duarte, Guaymate, La Romana, República Dominicana</p>
                </div>
              </div>

              <div className="flex items-start">
                <Phone className="w-6 h-6 text-amber-600 mr-4 mt-1" />
                <div>
                  <h4 className="font-semibold text-lg">Teléfono</h4>
                  <p>809 283 1603</p>
                </div>
              </div>

              <div className="flex items-start">
                <Mail className="w-6 h-6 text-amber-600 mr-4 mt-1" />
                <div>
                  <h4 className="font-semibold text-lg">Email</h4>
                  <p>johnsonzacky8@gmail.com</p>
                </div>
              </div>

              <div className="flex items-start">
                <Clock className="w-6 h-6 text-amber-600 mr-4 mt-1" />
                <div>
                  <h4 className="font-semibold text-lg">Horario</h4>
                  <p>Lunes a Viernes: 11:00 - 22:00</p>
                  <p>Sábados y Domingos: 12:00 - 23:00</p>
                </div>
              </div>
            </div>

            <div className="mt-8 h-64 bg-gray-200 rounded-lg">
              {/* Here you would integrate a map */}
              <div className="w-full h-full flex items-center justify-center">
                <p className="text-gray-500">Mapa de ubicación</p>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-2xl font-bold mb-6">Envíanos un Mensaje</h3>

            <form className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block mb-2">
                    Nombre
                  </label>
                  <Input id="name" placeholder="Tu nombre" />
                </div>
                <div>
                  <label htmlFor="email" className="block mb-2">
                    Email
                  </label>
                  <Input id="email" type="email" placeholder="Tu email" />
                </div>
              </div>

              <div>
                <label htmlFor="subject" className="block mb-2">
                  Asunto
                </label>
                <Input id="subject" placeholder="Asunto del mensaje" />
              </div>

              <div>
                <label htmlFor="message" className="block mb-2">
                  Mensaje
                </label>
                <Textarea id="message" placeholder="Tu mensaje" rows={5} />
              </div>

              <Button type="submit" className="w-full bg-amber-600 hover:bg-amber-700">
                Enviar Mensaje
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}

