"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header className="fixed w-full bg-white/90 backdrop-blur-sm z-50 shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="font-bold text-2xl text-amber-600">
            TONY EMPANADA
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-gray-700 hover:text-amber-600 font-medium">
              Inicio
            </Link>
            <Link href="#about" className="text-gray-700 hover:text-amber-600 font-medium">
              Nosotros
            </Link>
            <Link href="#menu" className="text-gray-700 hover:text-amber-600 font-medium">
              Menú
            </Link>
            <Link href="#contact" className="text-gray-700 hover:text-amber-600 font-medium">
              Contacto
            </Link>
            <Button className="bg-amber-600 hover:bg-amber-700">Ordenar Ahora</Button>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-gray-700"
            onClick={toggleMenu}
            aria-label={isMenuOpen ? "Cerrar menú" : "Abrir menú"}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t">
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            <Link href="/" className="text-gray-700 hover:text-amber-600 font-medium py-2" onClick={toggleMenu}>
              Inicio
            </Link>
            <Link href="#about" className="text-gray-700 hover:text-amber-600 font-medium py-2" onClick={toggleMenu}>
              Nosotros
            </Link>
            <Link href="#menu" className="text-gray-700 hover:text-amber-600 font-medium py-2" onClick={toggleMenu}>
              Menú
            </Link>
            <Link href="#contact" className="text-gray-700 hover:text-amber-600 font-medium py-2" onClick={toggleMenu}>
              Contacto
            </Link>
            <Button className="bg-amber-600 hover:bg-amber-700 w-full">Ordenar Ahora</Button>
          </div>
        </div>
      )}
    </header>
  )
}

