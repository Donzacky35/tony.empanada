import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import Navbar from "@/components/navbar"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Tony Empanada - Las mejores empanadas fritas",
  description:
    "Disfruta de las auténticas empanadas fritas de Tony Empanada. Sabor tradicional con ingredientes frescos y de calidad.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es" className="scroll-smooth">
      <body className={inter.className}>
        <Navbar />
        {children}
        <footer className="bg-gray-800 text-white py-8">
          <div className="container mx-auto px-4 text-center">
            <p>© {new Date().getFullYear()} Tony Empanada. Todos los derechos reservados.</p>
          </div>
        </footer>
      </body>
    </html>
  )
}



import './globals.css'