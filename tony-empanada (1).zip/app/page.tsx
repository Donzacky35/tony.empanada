import Hero from "@/components/hero"
import About from "@/components/about"
import Menu from "@/components/menu"
import Contact from "@/components/contact"
import SalesCalculator from "@/components/sales-calculator"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Hero />
      <About />
      <Menu />
      <SalesCalculator />
      <Contact />
    </main>
  )
}

